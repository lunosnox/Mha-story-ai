# Phone-only cloud build

This project includes a GitHub Actions workflow that builds the debug APK in the cloud. You do not need Android Studio or a computer.

## Simplest phone workflow

1. On your phone, create a new **private GitHub repository**.
2. Upload the contents of this project into the repository. If GitHub's mobile browser only lets you upload a ZIP, use the optional Codespaces method below to unzip it in the cloud.
3. Make sure `.github/workflows/build-apk.yml` is present.
4. Open the repository's **Actions** tab and select **Build Android APK**.
5. Tap **Run workflow** if it has not run automatically.
6. Wait for the green checkmark.
7. Open that workflow run and download the artifact named **MHA-Story-AI-debug-apk**.
8. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

## If you can only upload one ZIP from your phone

GitHub does not automatically unpack a ZIP into repository files. Use GitHub Codespaces (if available on your account):

1. Create an empty private repository.
2. Upload `MHAStoryAI-Functional-v3.zip` to the repository.
3. Open the repository in a Codespace.
4. In the Codespace terminal, run:

   `unzip MHAStoryAI-Functional-v3.zip -d /tmp/mha-unpacked`

   `cp -R /tmp/mha-unpacked/MHAStoryAI/. .`

   `rm MHAStoryAI-Functional-v3.zip`

5. Commit and push the extracted files.
6. GitHub Actions will automatically build the APK using `.github/workflows/build-apk.yml`.

## Important

- The APK is a **debug APK** intended for personal testing.
- The app has no ads.
- AI API keys entered in the app are stored locally. For a public release, use a backend rather than embedding a provider secret in the app.
- The workflow builds on GitHub's cloud machines, so Android SDK/Gradle do not need to be installed on your phone.
