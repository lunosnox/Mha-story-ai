# MHA Story AI

A functional Android prototype for an ongoing anime-style roleplay/story experience.

## Implemented

- Dark anime-inspired chat UI with NPC portraits.
- Player-only input: the AI is instructed never to write or decide the player's character.
- Multiple local stories: create, continue, rename, delete.
- JSON export/import of a complete story.
- Persistent Story Memory editor.
- Automatic memory updates from structured AI responses.
- Timeline, current situation, location, active-NPC and active-character context.
- Custom character profiles with portrait upload, personality, Quirk, backstory, relationships, goals, secrets and scene presence.
- Character editing after creation.
- Multi-character AI responses in a single turn.
- OpenAI-compatible chat-completions adapter with modular `AiEngine` interface.
- Placeholder AI works without an API key.
- No ads and no analytics.

## AI setup

Open **AI Settings** in the app and provide:

- Endpoint: an HTTPS OpenAI-compatible `/chat/completions` endpoint.
- API key.
- Model name.

The prototype stores these values locally in Android SharedPreferences. For a production release, route API calls through a secure backend so the provider key is not exposed in the APK.

## Memory behavior

The model is asked to return durable `memoryUpdates`. The app merges new facts into Story Memory, updates the timeline, and keeps the current situation available to later turns. The memory editor remains available so the player can correct or remove facts.

## Build

Open this folder in Android Studio, allow Gradle to sync, then use **Build > Build APK(s)**.

The project targets Android API 35 and supports Android 8.0+ (API 26).
