package com.example.mhastoryai;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.net.*;import android.view.*;import android.widget.*;import org.json.*;import java.io.*;import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    LinearLayout chat; ScrollView scroll; EditText input; JSONObject story; TextView send; TextView title; ProgressBar progress;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);load();
        chat=findViewById(R.id.chatContainer);scroll=findViewById(R.id.chatScroll);input=findViewById(R.id.input);send=findViewById(R.id.sendBtn);title=findViewById(R.id.title);
        findViewById(R.id.memoryBtn).setOnClickListener(v->startActivity(new Intent(this,MemoryActivity.class)));
        findViewById(R.id.charactersBtn).setOnClickListener(v->startActivity(new Intent(this,CharactersActivity.class)));
        findViewById(R.id.storyBtn).setOnClickListener(v->startActivity(new Intent(this,StoryListActivity.class)));
        findViewById(R.id.settingsBtn).setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        send.setOnClickListener(v->send()); render(); }
    void load(){story=Store.current(this);if(story.length()==0){story=Store.defaultStory();Store.addStory(this,story);}}
    @Override protected void onResume(){super.onResume();if(title!=null){load();render();}}
    void render(){title.setText(story.optString("name","MHA Story"));((TextView)findViewById(R.id.storyMeta)).setText("Chapter "+story.optInt("chapter",1)+" • "+story.optString("day","Day 1")+" • Player-controlled protagonist");
        chat.removeAllViews();JSONArray a=story.optJSONArray("messages");if(a!=null)for(int i=0;i<a.length();i++)try{JSONObject m=a.getJSONObject(i);addBubble(m.optString("speaker"),m.optString("text"),m.optBoolean("user"),m.optString("imageUri"));}catch(Exception ignored){} scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}
    String initials(String n){if(n==null||n.trim().isEmpty())return "?";String[] p=n.trim().split(" ");return (p[0].substring(0,1)+(p.length>1?p[p.length-1].substring(0,1):"")).toUpperCase();}
    String imageFor(String speaker){try{JSONArray cs=story.optJSONArray("characters");if(cs!=null)for(int i=0;i<cs.length();i++){JSONObject c=cs.getJSONObject(i);if(c.optString("name").equalsIgnoreCase(speaker))return c.optString("imageUri");}}catch(Exception ignored){}return "";}
    void addBubble(String speaker,String text,boolean user,String uri){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(user?Gravity.RIGHT:Gravity.LEFT);row.setPadding(0,dp(5),0,dp(5));
        String actual=uri.isEmpty()?(user?imageFor(story.optString("playerCharacter","Original Character")):imageFor(speaker)):uri;
        if(user){ row.addView(new Space(this),new LinearLayout.LayoutParams(0,1,1)); }
        if(!user || !actual.isEmpty()){TextView av=new TextView(this);av.setText(initials(speaker));av.setTextColor(Color.WHITE);av.setTextSize(12);av.setGravity(Gravity.CENTER);GradientDrawable ag=new GradientDrawable();ag.setColor(Color.parseColor("#303D70"));ag.setShape(GradientDrawable.OVAL);av.setBackground(ag);
            if(!actual.isEmpty())try{Bitmap bm=BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.parse(actual)));if(bm!=null){BitmapDrawable bd=new BitmapDrawable(getResources(),bm);bd.setBounds(0,0,dp(44),dp(44));av.setBackground(bd);}}catch(Exception ignored){}
            row.addView(av,new LinearLayout.LayoutParams(dp(44),dp(44)));}
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);col.setPadding(user?dp(36):dp(8),0,user?0:dp(8),0);TextView name=new TextView(this);name.setText(speaker);name.setTextColor(user?Color.parseColor("#B9C5FF"):Color.parseColor("#68DFFF"));name.setTextSize(12);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);col.addView(name);
        TextView bubble=new TextView(this);bubble.setText(text);bubble.setTextColor(Color.WHITE);bubble.setTextSize(16);bubble.setLineSpacing(0,1.12f);bubble.setPadding(dp(14),dp(11),dp(14),dp(11));bubble.setBackgroundResource(user?R.drawable.bg_user:R.drawable.bg_npc);col.addView(bubble,new LinearLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.78),-2));row.addView(col);chat.addView(row);
    }
    void updateActiveCharacters(){try{JSONArray cs=story.optJSONArray("characters");StringBuilder b=new StringBuilder();if(cs!=null)for(int i=0;i<cs.length();i++){JSONObject c=cs.getJSONObject(i);if(c.optBoolean("present",false)){if(b.length()>0)b.append(", ");b.append(c.optString("name"));}}if(b.length()==0)b.append("All Might");story.put("activeCharacters",b.toString());}catch(Exception ignored){}}
    void setBusy(boolean busy){send.setEnabled(!busy);input.setEnabled(!busy);send.setAlpha(busy?.45f:1f);}
    void send(){String u=input.getText().toString().trim();if(u.isEmpty())return;input.setText("");setBusy(true);try{
            JSONArray a=story.optJSONArray("messages");if(a==null){a=new JSONArray();story.put("messages",a);}a.put(new JSONObject().put("speaker","You").put("text",u).put("user",true));
            updateActiveCharacters(); Store.upsert(this,story);render();
            new Thread(()->{try{AiEngine ai=Store.aiEngine(this);AiEngine.AiResult result=ai.generate(story,u);runOnUiThread(()->applyAi(result));}catch(Exception e){runOnUiThread(()->{setBusy(false);Toast.makeText(this,"AI error: "+e.getMessage(),Toast.LENGTH_LONG).show();});}}).start();
        }catch(Exception e){setBusy(false);Toast.makeText(this,"Could not save message",Toast.LENGTH_SHORT).show();}}
    void applyAi(AiEngine.AiResult r){try{
        JSONArray a=story.optJSONArray("messages");if(a==null){a=new JSONArray();story.put("messages",a);}for(int i=0;i<r.messages.length();i++){JSONObject m=r.messages.getJSONObject(i);String speaker=m.optString("speaker","Narrator");String text=m.optString("text","");a.put(new JSONObject().put("speaker",speaker).put("text",text).put("user",false).put("imageUri",imageFor(speaker)));}
        story.put("activeNpc",r.activeNpc);story.put("chapter",r.chapter);story.put("day",r.day);MemoryEngine.apply(story,r.memoryUpdates);Store.upsert(this,story);setBusy(false);render();
    }catch(Exception e){setBusy(false);Toast.makeText(this,"Could not apply AI response",Toast.LENGTH_SHORT).show();}}
}
