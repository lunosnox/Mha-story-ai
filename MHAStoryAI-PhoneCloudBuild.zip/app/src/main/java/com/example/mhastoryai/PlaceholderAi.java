package com.example.mhastoryai;

import org.json.*;

public class PlaceholderAi implements AiEngine {
    public AiResult generate(JSONObject story, String userText) throws Exception {
        String npc = story.optString("activeNpc", "All Might");
        JSONArray messages = new JSONArray();
        messages.put(new JSONObject().put("speaker", npc).put("text", "The moment stretches for a beat as everyone reacts to what you just did. " +
                "The scene remains open, waiting for your next choice."));
        return new AiResult(messages, new JSONArray(), npc, story.optInt("chapter", 1), story.optString("day", "Day 1"));
    }
}
