package com.example.mhastoryai;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

public class ApiAiEngine implements AiEngine {
    private final String endpoint,key,model;
    public ApiAiEngine(String e,String k,String m){endpoint=e;key=k;model=m;}

    public AiResult generate(JSONObject story,String userText)throws Exception{
        JSONObject body=new JSONObject();
        body.put("model",model);
        body.put("temperature",0.9);
        body.put("response_format", new JSONObject().put("type","json_object"));
        JSONArray msgs=new JSONArray();
        msgs.put(new JSONObject().put("role","system").put("content",buildContext(story)));
        msgs.put(new JSONObject().put("role","user").put("content",userText));
        body.put("messages",msgs);

        HttpURLConnection h=(HttpURLConnection)new URL(endpoint).openConnection();
        h.setRequestMethod("POST"); h.setConnectTimeout(20000); h.setReadTimeout(90000); h.setDoOutput(true);
        h.setRequestProperty("Content-Type","application/json");
        h.setRequestProperty("Authorization","Bearer "+key);
        try(OutputStream o=h.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        int code=h.getResponseCode();
        InputStream in=code<400?h.getInputStream():h.getErrorStream();
        String raw=read(in);
        if(code>=400)throw new IOException("HTTP "+code+": "+raw);
        JSONObject response=new JSONObject(raw);
        String content=response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        JSONObject result=parseJson(content);
        return fromResult(result,story);
    }

    private String buildContext(JSONObject story){
        StringBuilder c=new StringBuilder(AiEngine.SYSTEM);
        c.append("\n\nSTORY MEMORY:\n").append(story.optString("memory",""));
        c.append("\n\nTIMELINE:\n").append(story.optString("timeline",""));
        c.append("\n\nCURRENT SITUATION:\n").append(story.optString("currentSituation",""));
        c.append("\n\nCURRENT LOCATION:\n").append(story.optString("location",""));
        c.append("\n\nACTIVE CHARACTERS:\n").append(story.optString("activeCharacters",""));
        c.append("\n\nCHARACTER PROFILES:\n");
        JSONArray cs=story.optJSONArray("characters");
        if(cs!=null)for(int i=0;i<cs.length();i++)c.append(cs.optJSONObject(i).toString()).append("\n");
        c.append("\n\nRECENT SCENE:\n");
        JSONArray ms=story.optJSONArray("messages");
        if(ms!=null){int start=Math.max(0,ms.length()-24);for(int i=start;i<ms.length();i++){JSONObject x=ms.optJSONObject(i);if(x!=null)c.append(x.optString("speaker")).append(": ").append(x.optString("text")).append("\n");}}
        return c.toString();
    }

    private JSONObject parseJson(String content)throws Exception{
        String s=content.trim();
        if(s.startsWith("```")){int first=s.indexOf('{');int last=s.lastIndexOf('}');if(first>=0&&last>first)s=s.substring(first,last+1);}
        return new JSONObject(s);
    }

    private AiResult fromResult(JSONObject r, JSONObject story)throws Exception{
        JSONArray out=new JSONArray(); JSONArray raw=r.optJSONArray("messages");
        if(raw!=null)for(int i=0;i<raw.length();i++){
            JSONObject x=raw.optJSONObject(i); if(x==null)continue;
            String speaker=x.optString("speaker","Narrator").trim(); String text=x.optString("text","").trim();
            if(!text.isEmpty())out.put(new JSONObject().put("speaker",speaker.isEmpty()?"Narrator":speaker).put("text",text));
        }
        if(out.length()==0)out.put(new JSONObject().put("speaker",story.optString("activeNpc","Narrator")).put("text","The scene continues, but the response contained no dialogue."));
        JSONArray updates=r.optJSONArray("memoryUpdates"); if(updates==null)updates=new JSONArray();
        return new AiResult(out,updates,r.optString("activeNpc",story.optString("activeNpc","Narrator")),r.optInt("chapter",story.optInt("chapter",1)),r.optString("day",story.optString("day","Day 1")));
    }
    static String read(InputStream i)throws Exception{BufferedReader b=new BufferedReader(new InputStreamReader(i,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String x;while((x=b.readLine())!=null)s.append(x);return s.toString();}
}
