package com.example.mhastoryai;

import org.json.*;import java.util.*;

public final class MemoryEngine {
    private MemoryEngine(){}
    public static JSONArray detectUserFacts(String text){ JSONArray a=new JSONArray(); String t=text.toLowerCase(Locale.US); try{ if(t.contains("killed my father")||t.contains("kill my father")||t.contains("killed his father"))a.put("The protagonist killed his father."); if(t.contains("joined all might")||t.contains("became all might's student")||t.contains("became all might’s student"))a.put("The protagonist is posing as All Might’s student."); if(t.contains("villain attack")||t.contains("villains attack")||t.contains("villains attacked"))a.put("A villain attack occurred during the current event."); }catch(Exception ignored){} return a; }
    public static void apply(JSONObject story, JSONArray updates){
        try{
            String memory=story.optString("memory",""); StringBuilder out=new StringBuilder(memory.trim());
            for(int i=0;i<updates.length();i++){String u=updates.optString(i,"").trim();if(u.isEmpty()||containsFact(memory,u))continue;if(out.length()>0&&!out.toString().endsWith("\n"))out.append('\n');out.append("• ").append(u);memory=out.toString();}
            story.put("memory",out.toString());
            story.put("currentSituation",summarizeSituation(story));
            story.put("timeline",appendTimeline(story,updates));
        }catch(Exception ignored){}
    }
    static boolean containsFact(String memory,String fact){return memory.toLowerCase(Locale.US).contains(fact.toLowerCase(Locale.US));}
    static String summarizeSituation(JSONObject story){String loc=story.optString("location","");String npc=story.optString("activeNpc","Narrator");String base=story.optString("currentSituation","");if(base.isEmpty())base="The scene is ongoing.";return base+" Active NPC: "+npc+". Location: "+loc+".";}
    static String appendTimeline(JSONObject story,JSONArray updates){String t=story.optString("timeline","");if(updates.length()==0)return t;StringBuilder s=new StringBuilder(t);if(s.length()>0&&!s.toString().endsWith("\n"))s.append('\n');s.append("Recent durable events:\n");for(int i=0;i<updates.length();i++)s.append("• ").append(updates.optString(i)).append('\n');return s.toString().trim();}
}
