package com.example.mhastoryai;

import android.content.*;
import org.json.*;
import java.util.*;

public class Store {
    static final String PREF="mha_store";
    static SharedPreferences p(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static JSONArray stories(Context c){try{return new JSONArray(p(c).getString("stories","[]"));}catch(Exception e){return new JSONArray();}}
    static void saveStories(Context c,JSONArray a){p(c).edit().putString("stories",a.toString()).apply();}
    static JSONObject current(Context c){try{return new JSONObject(p(c).getString("current","{}"));}catch(Exception e){return new JSONObject();}}
    static void setCurrent(Context c,JSONObject o){p(c).edit().putString("current",o.toString()).apply();}

    static JSONObject defaultStory(){
        JSONObject o=new JSONObject();
        try{
            o.put("id",UUID.randomUUID().toString()); o.put("name","The Path to All Might"); o.put("chapter",1); o.put("day","Day 1");
            o.put("activeNpc","All Might"); o.put("playerCharacter","Original Character"); o.put("location","U.A. High — Press Conference");
            o.put("activeCharacters","All Might, Izuku Midoriya (Deku), Katsuki Bakugo, Shota Aizawa, Original Character");
            o.put("currentSituation","The hero-related press conference is underway. The protagonist is pretending to seek All Might's mentorship while secretly planning an assassination. A villain attack may develop naturally.");
            o.put("timeline","Before story: protagonist was in Class 1-A. Childhood memories returned. He left during a class field trip, found and killed his father, then encountered All For One. All For One took him in and trained/used him for two years. Current: protagonist is infiltrating a press conference and posing as an admirer/potential student.");
            o.put("memory","MAIN CHARACTER\n• Formerly a member of Class 1-A.\n• Recovered repressed childhood memories.\n• Killed his father.\n\nKEY EVENTS\n• All For One took him in.\n• Two years of training/manipulation passed.\n\nOBJECTIVE\n• Secret mission: kill All Might.\n\nRELATIONSHIPS\n• All Might does not know the protagonist's true identity or mission.\n• Protagonist is pretending to become All Might's student.\n\nCURRENT SITUATION\n• Press conference/event is underway.\n• Villain attack can develop naturally.\n\nAI RULE\n• Never control the player's dialogue, thoughts, actions, feelings, or decisions unless explicitly allowed.");
            JSONArray msgs=new JSONArray(); msgs.put(new JSONObject().put("speaker","All Might").put("text","It's good to see you again. Are you ready for today's training?").put("user",false)); o.put("messages",msgs); JSONArray seeded=seedCharacters(); for(int i=0;i<seeded.length();i++){JSONObject c=seeded.optJSONObject(i); if(c!=null && (c.optString("name").equals("All Might")||c.optString("name").equals("Izuku Midoriya (Deku)")||c.optString("name").equals("Katsuki Bakugo")||c.optString("name").equals("Shota Aizawa")||c.optString("name").equals("Original Character"))) c.put("present",true);} o.put("characters",seeded);
        }catch(Exception ignored){} return o;
    }
    static JSONArray seedCharacters(){
        JSONArray a=new JSONArray(); try{
            a.put(charc("All Might","49","Tall, muscular, blond hero","Powerful, encouraging, observant","One For All","Symbol of Peace and public hero","Potential student; unaware of the protagonist's secret","Protect people and inspire the next generation","Does not know the assassination plan"));
            a.put(charc("Izuku Midoriya (Deku)","16","Green-haired student","Analytical, kind, earnest","One For All","Class 1-A student","Former classmate of protagonist","Become a great hero","None established"));
            a.put(charc("Katsuki Bakugo","16","Spiky blond hair","Blunt, competitive, intense","Explosion","Class 1-A student","Former classmate of protagonist","Become the #1 hero","None established"));
            a.put(charc("Shota Aizawa","31","Dark hair, tired eyes","Dry, vigilant, pragmatic","Erasure","U.A. teacher","Former teacher of protagonist","Keep students alive and disciplined","Suspicious of unusual behavior"));
            a.put(charc("All For One","Unknown","Masked, imposing figure","Calculating, manipulative, patient","All For One","Villain mastermind","Took protagonist in and trained him","Control successors and pursue long-term plans","Knows protagonist's true mission"));
            a.put(charc("Original Character","18","Customizable","Customizable","Customizable","Former Class 1-A member","Secret connection to All For One","Kill All Might","Working for All For One"));
        }catch(Exception ignored){} return a;
    }
    static JSONObject charc(String n,String age,String app,String per,String q,String back,String rel,String goals,String sec){JSONObject x=new JSONObject();try{x.put("name",n);x.put("age",age);x.put("appearance",app);x.put("personality",per);x.put("quirk",q);x.put("backstory",back);x.put("relationships",rel);x.put("goals",goals);x.put("secrets",sec);x.put("imageUri","");x.put("present",false);}catch(Exception ignored){}return x;}
    static void addStory(Context c,JSONObject o){JSONArray a=stories(c);a.put(o);saveStories(c,a);setCurrent(c,o);}
    static void upsertCurrent(Context c){JSONObject cur=current(c);upsert(c,cur);}
    static void upsert(Context c,JSONObject cur){JSONArray a=stories(c);for(int i=0;i<a.length();i++)try{if(a.getJSONObject(i).optString("id").equals(cur.optString("id"))){a.put(i,cur);saveStories(c,a);setCurrent(c,cur);return;}}catch(Exception ignored){}a.put(cur);saveStories(c,a);setCurrent(c,cur);}
    static void deleteStory(Context c,String id){JSONArray a=stories(c),out=new JSONArray();for(int i=0;i<a.length();i++)try{if(!a.getJSONObject(i).optString("id").equals(id))out.put(a.getJSONObject(i));}catch(Exception ignored){}saveStories(c,out);JSONObject cur=current(c);if(id.equals(cur.optString("id"))){if(out.length()>0)setCurrent(c,out.optJSONObject(0));else setCurrent(c,new JSONObject());}}
    static AiEngine aiEngine(Context c){String e=p(c).getString("endpoint","");String k=p(c).getString("apikey","");String m=p(c).getString("model","");return e.length()>0&&k.length()>0&&m.length()>0?new ApiAiEngine(e,k,m):new PlaceholderAi();}
}
